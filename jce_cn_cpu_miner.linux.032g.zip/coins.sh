#!/bin/sh

./start.sh --coins
